from flask import Flask

app = Flask("src")

from src.controllers import *
